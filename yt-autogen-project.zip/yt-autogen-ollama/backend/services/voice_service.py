"""
Voice/TTS Service — converts script text into voiceover audio.
Tries edge-tts first (higher quality, free, no key needed),
falls back to gTTS (also free, no key needed).
"""
import io
import os
import base64
import asyncio
import logging
from fastapi.concurrency import run_in_threadpool

logger = logging.getLogger(__name__)

LANG_MAP = {
    "English": "en", "Urdu": "ur", "Hindi": "hi", "Spanish": "es",
    "French": "fr", "Arabic": "ar", "German": "de", "Portuguese": "pt",
}

EDGE_VOICE_MAP = {
    "English": "en-US-AriaNeural",
    "Urdu": "ur-PK-AsadNeural",
    "Hindi": "hi-IN-MadhurNeural",
    "Spanish": "es-ES-AlvaroNeural",
    "French": "fr-FR-DeniseNeural",
    "Arabic": "ar-SA-HamedNeural",
    "German": "de-DE-ConradNeural",
    "Portuguese": "pt-BR-FranciscaNeural",
}


async def _generate_edge_tts(text: str, language: str = "English") -> bytes:
    """Generate audio using edge-tts (high quality, free)."""
    import edge_tts
    voice = EDGE_VOICE_MAP.get(language, "en-US-AriaNeural")
    communicate = edge_tts.Communicate(text, voice)
    audio_chunks = []
    async for chunk in communicate.stream():
        if chunk["type"] == "audio":
            audio_chunks.append(chunk["data"])
    return b"".join(audio_chunks)


def _generate_gtts(text: str, language: str = "English") -> bytes:
    """Generate audio using gTTS (reliable fallback)."""
    from gtts import gTTS
    lang_code = LANG_MAP.get(language, "en")
    tts = gTTS(text=text, lang=lang_code, slow=False)
    buf = io.BytesIO()
    tts.write_to_fp(buf)
    buf.seek(0)
    return buf.read()


def _truncate_for_tts(text: str, max_chars: int = 3000) -> str:
    """Limit text length to keep TTS generation fast and reliable."""
    if len(text) <= max_chars:
        return text
    truncated = text[:max_chars]
    last_period = truncated.rfind(".")
    if last_period > max_chars * 0.7:
        return truncated[:last_period + 1]
    return truncated


async def generate_voiceover_async(text: str, language: str = "English") -> str:
    """Generate voiceover audio, returns base64-encoded MP3."""
    text = _truncate_for_tts(text)

    try:
        audio_bytes = await _generate_edge_tts(text, language)
        if audio_bytes:
            logger.info("Voiceover generated via edge-tts")
            return base64.b64encode(audio_bytes).decode("utf-8")
        raise ValueError("edge-tts returned empty audio")
    except Exception as e:
        logger.warning(f"edge-tts failed ({e}), falling back to gTTS")

    try:
        audio_bytes = await run_in_threadpool(_generate_gtts, text, language)
        logger.info("Voiceover generated via gTTS")
        return base64.b64encode(audio_bytes).decode("utf-8")
    except Exception as e:
        logger.error(f"gTTS also failed: {e}")
        raise RuntimeError(f"Voice generation failed: {e}")


def generate_voiceover(text: str, language: str = "English") -> str:
    """Synchronous wrapper for use in non-async contexts."""
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            # Already in async context — caller should use async version directly
            raise RuntimeError("Use generate_voiceover_async in async contexts")
        return loop.run_until_complete(generate_voiceover_async(text, language))
    except RuntimeError:
        return asyncio.run(generate_voiceover_async(text, language))
