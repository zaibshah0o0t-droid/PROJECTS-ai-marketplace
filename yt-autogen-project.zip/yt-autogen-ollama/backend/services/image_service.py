"""
Thumbnail Generation Service.

Tries Stable Diffusion via Replicate.com first (if REPLICATE_API_TOKEN is set),
then falls back to a professional PIL-based generator that ALWAYS works
without any external API — this guarantees thumbnail generation never fails.
"""
import io
import os
import base64
import logging
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageEnhance

logger = logging.getLogger(__name__)

WIDTH, HEIGHT = 1280, 720
REPLICATE_API_TOKEN = os.getenv("REPLICATE_API_TOKEN", "")

STYLES = {
    "Cinematic": {
        "bg_colors": [(15, 12, 41), (48, 43, 99), (36, 36, 62)],
        "accent": (255, 215, 0), "text_color": (255, 255, 255),
        "sub_color": (200, 180, 120), "font_scale": 1.0,
    },
    "Bold": {
        "bg_colors": [(220, 20, 60), (139, 0, 0), (255, 60, 0)],
        "accent": (255, 255, 0), "text_color": (255, 255, 255),
        "sub_color": (255, 230, 100), "font_scale": 1.1,
    },
    "Minimalist": {
        "bg_colors": [(10, 10, 20), (20, 20, 35), (15, 15, 28)],
        "accent": (100, 200, 255), "text_color": (240, 240, 255),
        "sub_color": (150, 180, 220), "font_scale": 0.9,
    },
    "Colorful": {
        "bg_colors": [(255, 100, 0), (255, 0, 150), (100, 0, 255)],
        "accent": (0, 255, 200), "text_color": (255, 255, 255),
        "sub_color": (200, 255, 220), "font_scale": 1.05,
    },
    "Gaming": {
        "bg_colors": [(0, 5, 20), (0, 20, 60), (10, 0, 30)],
        "accent": (0, 255, 100), "text_color": (255, 255, 255),
        "sub_color": (100, 255, 150), "font_scale": 1.1,
    },
}


def _load_font(size: int, bold: bool = False):
    paths = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
        "C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf",
        "/System/Library/Fonts/Helvetica.ttc",
    ]
    for p in paths:
        try:
            return ImageFont.truetype(p, size)
        except (IOError, OSError):
            continue
    return ImageFont.load_default()


def _draw_gradient_bg(draw, colors, width, height, style_name):
    c1, c2 = colors[0], colors[1] if len(colors) > 1 else colors[0]
    c3 = colors[2] if len(colors) > 2 else c2
    for y in range(height):
        t = y / height
        if t < 0.5:
            t2 = t * 2
            r = int(c1[0]*(1-t2) + c2[0]*t2); g = int(c1[1]*(1-t2) + c2[1]*t2); b = int(c1[2]*(1-t2) + c2[2]*t2)
        else:
            t2 = (t - 0.5) * 2
            r = int(c2[0]*(1-t2) + c3[0]*t2); g = int(c2[1]*(1-t2) + c3[1]*t2); b = int(c2[2]*(1-t2) + c3[2]*t2)
        draw.line([(0, y), (width, y)], fill=(r, g, b))


def _draw_decorative_elements(img, draw, style, s_name):
    accent = style["accent"]
    if s_name == "Cinematic":
        draw.rectangle([(0, 0), (WIDTH, 60)], fill=(0, 0, 0, 200))
        draw.rectangle([(0, HEIGHT-60), (WIDTH, HEIGHT)], fill=(0, 0, 0, 200))
        draw.rectangle([(0, 0), (6, HEIGHT)], fill=tuple(list(accent)+[180]))
        draw.rectangle([(WIDTH-6, 0), (WIDTH, HEIGHT)], fill=tuple(list(accent)+[180]))
    elif s_name == "Bold":
        draw.rectangle([(0, 0), (WIDTH, 12)], fill=accent)
        draw.rectangle([(0, HEIGHT-12), (WIDTH, HEIGHT)], fill=accent)
    elif s_name == "Minimalist":
        lw, sz = 3, 60
        col = tuple(list(accent)+[200])
        draw.rectangle([(30, 30), (30+sz, 30+lw)], fill=col)
        draw.rectangle([(30, 30), (30+lw, 30+sz)], fill=col)
        draw.rectangle([(WIDTH-30-sz, 30), (WIDTH-30, 30+lw)], fill=col)
        draw.rectangle([(WIDTH-30-lw, 30), (WIDTH-30, 30+sz)], fill=col)
        draw.rectangle([(30, HEIGHT-30-lw), (30+sz, HEIGHT-30)], fill=col)
        draw.rectangle([(30, HEIGHT-30-sz), (30+lw, HEIGHT-30)], fill=col)
        draw.rectangle([(WIDTH-30-sz, HEIGHT-30-lw), (WIDTH-30, HEIGHT-30)], fill=col)
        draw.rectangle([(WIDTH-30-lw, HEIGHT-30-sz), (WIDTH-30, HEIGHT-30)], fill=col)
    elif s_name == "Colorful":
        overlay = Image.new("RGBA", (WIDTH, HEIGHT), (0, 0, 0, 0))
        od = ImageDraw.Draw(overlay)
        for (cx, cy, r), col in zip([(1050,100,220),(200,600,180),(900,600,150)],
                                     [(255,255,0,25),(0,255,200,20),(255,100,255,20)]):
            od.ellipse([(cx-r, cy-r), (cx+r, cy+r)], fill=col)
        img.paste(Image.alpha_composite(img.convert("RGBA"), overlay).convert("RGB"), (0, 0))
    elif s_name == "Gaming":
        draw.rectangle([(0, 0), (WIDTH, 4)], fill=accent)
        draw.rectangle([(0, HEIGHT-4), (WIDTH, HEIGHT)], fill=accent)


def _draw_text_with_shadow(draw, pos, text, font, color, shadow_offset=4):
    x, y = pos
    for dx in (-shadow_offset, 0, shadow_offset):
        for dy in (-shadow_offset, 0, shadow_offset):
            if dx or dy:
                draw.text((x+dx, y+dy), text, font=font, fill=(0, 0, 0))
    draw.text((x, y), text, font=font, fill=color)


def _draw_play_button(draw, x, y, size=50):
    r = size // 3
    draw.rounded_rectangle([(x-size, y-r), (x+size, y+r)], radius=r//2, fill=(255, 0, 0, 220))
    draw.polygon([(x-size//4, y-size//4), (x-size//4, y+size//4), (x+size//3, y)], fill=(255, 255, 255))


def _generate_pil_thumbnail(topic: str, style_name: str, custom_image: bytes = None) -> str:
    """The reliable, always-works PIL thumbnail generator."""
    style = STYLES.get(style_name, STYLES["Cinematic"])

    if custom_image:
        try:
            base = Image.open(io.BytesIO(custom_image)).convert("RGB").resize((WIDTH, HEIGHT), Image.LANCZOS)
            base = ImageEnhance.Brightness(base).enhance(0.5)
        except Exception:
            base = Image.new("RGB", (WIDTH, HEIGHT), style["bg_colors"][0])
    else:
        base = Image.new("RGB", (WIDTH, HEIGHT), style["bg_colors"][0])

    img = base.copy()
    draw = ImageDraw.Draw(img, "RGBA")
    if not custom_image:
        _draw_gradient_bg(draw, style["bg_colors"], WIDTH, HEIGHT, style_name)
    _draw_decorative_elements(img, draw, style, style_name)
    draw = ImageDraw.Draw(img, "RGBA")

    words, lines, current = topic.split(), [], ""
    for w in words:
        test = (current + " " + w).strip()
        if len(test) <= 22:
            current = test
        else:
            if current: lines.append(current)
            current = w
    if current: lines.append(current)
    lines = lines[:3]

    fs = style["font_scale"]
    base_fs = int(90*fs) if len(lines) == 1 else int(72*fs) if len(lines) == 2 else int(58*fs)
    font_main = _load_font(base_fs, bold=True)
    font_label = _load_font(int(26*fs), bold=True)

    line_h = base_fs + 16
    total_h = len(lines) * line_h
    start_y = (HEIGHT - total_h) // 2 - 30
    draw.rectangle([(80, start_y-20), (86, start_y+total_h+20)], fill=style["accent"])

    for i, line in enumerate(lines):
        _draw_text_with_shadow(draw, (100, start_y + i*line_h), line.upper(), font_main, style["text_color"])

    label_y = start_y + total_h + 20
    label = f"▶  {style_name.upper()} CONTENT"
    draw.rectangle([(96, label_y), (96+len(label)*14, label_y+36)], fill=tuple(list(style["accent"])+[40]))
    draw.text((100, label_y+4), label, font=font_label, fill=style["sub_color"])

    _draw_play_button(draw, WIDTH-120, HEIGHT-80, size=50)

    vignette = Image.new("RGBA", (WIDTH, HEIGHT), (0, 0, 0, 0))
    vd = ImageDraw.Draw(vignette)
    for i in range(120):
        alpha = int(180 * (1 - i/120) ** 2)
        vd.rectangle([(i, i), (WIDTH-i, HEIGHT-i)], outline=(0, 0, 0, alpha))
    img = Image.alpha_composite(img.convert("RGBA"), vignette).convert("RGB")
    img = img.filter(ImageFilter.UnsharpMask(radius=1.5, percent=120, threshold=3))

    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=95, optimize=True)
    buf.seek(0)
    return base64.b64encode(buf.read()).decode("utf-8")


def _generate_replicate_thumbnail(topic: str, style_name: str) -> str:
    """Generate via Replicate Stable Diffusion API. Raises on any failure."""
    import replicate

    style_prompts = {
        "Cinematic": "cinematic lighting, dramatic, film grain, moody atmosphere",
        "Bold": "bold vibrant colors, high contrast, dynamic energy, dramatic",
        "Minimalist": "minimalist clean design, simple composition, modern",
        "Colorful": "vibrant rainbow colors, playful, energetic, eye-catching",
        "Gaming": "neon cyberpunk gaming aesthetic, futuristic, glowing effects",
    }
    style_desc = style_prompts.get(style_name, style_prompts["Cinematic"])
    prompt = f"YouTube thumbnail background for a video about '{topic}', {style_desc}, professional, high quality, 16:9, no text"

    client = replicate.Client(api_token=REPLICATE_API_TOKEN)
    output = client.run(
        "stability-ai/stable-diffusion:ac732df83cea7fff18b8472768c88ad041fa750ff7682a21affe81863cbe77e4",
        input={"prompt": prompt, "width": 1280, "height": 720, "num_outputs": 1}
    )
    import httpx
    image_url = output[0] if isinstance(output, list) else output
    resp = httpx.get(image_url, timeout=30)
    resp.raise_for_status()
    return base64.b64encode(resp.content).decode("utf-8")


def generate_thumbnail(topic: str, style_name: str = "Cinematic", custom_image: bytes = None) -> str:
    """
    Generate a professional 1280x720 thumbnail.
    Tries Replicate Stable Diffusion first (if configured), always falls back to PIL.
    """
    if REPLICATE_API_TOKEN and not custom_image:
        try:
            logger.info(f"Attempting Replicate SD generation for: {topic}")
            return _generate_replicate_thumbnail(topic, style_name)
        except Exception as e:
            logger.warning(f"Replicate generation failed ({e}), using PIL fallback")

    return _generate_pil_thumbnail(topic, style_name, custom_image)
