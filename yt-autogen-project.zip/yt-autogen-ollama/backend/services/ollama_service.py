"""
Ollama AI Service — handles all text generation (script, SEO).
Falls back to built-in templates when Ollama is unavailable.
"""
import os
import json
import logging
from typing import Optional
from dotenv import load_dotenv
from backend.utils.helpers import clean_json

load_dotenv()
logger = logging.getLogger(__name__)

OLLAMA_HOST  = os.getenv("OLLAMA_HOST", "http://127.0.0.1:11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3.2")


def _ollama_chat(prompt: str, system: str = "", json_mode: bool = False) -> str:
    """Call Ollama and return response text. Raises on failure.

    json_mode=True asks the Ollama server itself to constrain output to
    valid JSON (supported since Ollama 0.1.9+), which significantly
    reduces malformed-JSON fallbacks compared to relying on the model
    to follow the system prompt alone.
    """
    try:
        import ollama
        client = ollama.Client(host=OLLAMA_HOST)
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})
        kwargs = {"model": OLLAMA_MODEL, "messages": messages}
        if json_mode:
            kwargs["format"] = "json"
        response = client.chat(**kwargs)
        return response["message"]["content"]
    except Exception as e:
        logger.warning(f"Ollama unavailable ({e}), using fallback")
        raise


def _ollama_available() -> bool:
    """Quick check if Ollama is reachable."""
    try:
        import ollama
        client = ollama.Client(host=OLLAMA_HOST)
        client.list()
        return True
    except Exception:
        return False


# ─── Script Generation ────────────────────────────────────────────────────────

def generate_script(
    topic: str,
    tone: str = "Educational",
    duration: int = 10,
    target_audience: Optional[str] = None,
    language: str = "English",
) -> dict:
    """Generate YouTube script via Ollama, with fallback."""
    word_count = duration * 150
    audience_line = f"Target audience: {target_audience}." if target_audience else ""

    system = "You are an expert YouTube scriptwriter. Always respond with valid JSON only. No markdown, no explanation."
    prompt = f"""Write a complete YouTube video script.

Topic: {topic}
Tone: {tone}
Duration: {duration} minutes (~{word_count} words)
Language: {language}
{audience_line}

Return ONLY this JSON structure:
{{
  "hook": "Attention-grabbing 0-15 second opening. Bold statement or shocking fact. 2-3 sentences.",
  "intro": "15-60 second intro. Welcome viewers, introduce topic, tease value. 3-4 sentences.",
  "body": "Main content body (~{int(word_count*0.75)} words). Include [TIMESTAMP: X:XX] markers every 2 minutes, [CUT TO B-ROLL] cues, [GRAPHIC] notes, section headers, bullet points for key ideas, stories and examples, and a mid-video engagement prompt like 'Drop a comment below if...'",
  "outro": "30-45 second outro. Recap key points, strong subscribe CTA, comment question, tease next video.",
  "timestamps": ["0:00 - Introduction", "1:30 - First Point", "4:00 - Second Point", "7:00 - Advanced Tips", "9:30 - Conclusion"],
  "full_script": "Complete combined teleprompter-ready script with all sections. ~{word_count} words total."
}}"""

    try:
        raw = _ollama_chat(prompt, system, json_mode=True)
        data = json.loads(clean_json(raw))
        # Validate required keys
        for key in ["hook", "intro", "body", "outro", "full_script"]:
            if key not in data:
                raise ValueError(f"Missing key: {key}")
        if "timestamps" not in data:
            data["timestamps"] = [f"0:00 - Introduction", f"{duration-1}:00 - Conclusion"]
        logger.info(f"Script generated via Ollama for: {topic}")
        return data
    except Exception as e:
        logger.warning(f"Script fallback triggered: {e}")
        return _fallback_script(topic, tone, duration)


def _fallback_script(topic: str, tone: str, duration: int) -> dict:
    wc = duration * 150
    hook = (
        f"What if I told you that {topic} could completely transform your results in just {duration} minutes? "
        f"Stay with me — because by the end of this video, you'll have everything you need to take action TODAY."
    )
    intro = (
        f"What's up everyone, welcome back to the channel! Today we're going deep on {topic}. "
        f"I've spent weeks researching this and I found some things that genuinely surprised me. "
        f"Whether you're a complete beginner or you've been at this for years, there's something here for you. "
        f"Let's get straight into it."
    )
    body = f"""[TIMESTAMP: 0:00] Introduction to {topic}

Let's start from the very beginning. {topic} is one of the most important areas you can focus on right now, and here's exactly why:

• Point 1: It fundamentally changes how you approach the problem
• Point 2: Early adopters consistently see 3-5x better results
• Point 3: The barrier to entry has never been lower

[CUT TO B-ROLL]

[TIMESTAMP: 2:30] The Core Framework

Here's the proven framework that top performers use:

Step 1 — Research deeply before taking any action
Step 2 — Start small with low-risk experiments to validate your approach
Step 3 — Double down on what works, eliminate what doesn't
Step 4 — Systematize your wins so they become repeatable

[GRAPHIC: Show 4-step framework diagram]

🎯 Engagement Hook: "Which of these steps do you find most challenging? Drop it in the comments — I read every single one."

[TIMESTAMP: 5:00] Real-World Examples and Case Studies

Let me walk you through exactly how real people are using {topic} right now.

Example 1: A small creator who went from 0 to 50K subscribers in 6 months
Example 2: A business owner who cut production time in half
Example 3: A student who landed their dream job using these exact principles

The common thread? They all followed the framework I just showed you.

[CUT TO B-ROLL]

[TIMESTAMP: 7:30] Advanced Strategies (Most People Skip These)

Now for the part that separates good from great:

Advanced Strategy 1: Stack multiple approaches simultaneously
Advanced Strategy 2: Use data to make every decision — never guess
Advanced Strategy 3: Build systems, not just habits

[PAUSE]

[TIMESTAMP: 9:00] Common Mistakes to Avoid

Before we wrap up, here are the mistakes I see people make over and over:

❌ Mistake 1: Moving too fast without validating first
❌ Mistake 2: Copying others instead of adapting to your situation
❌ Mistake 3: Giving up 20 feet from the gold

The truth is — most people quit right before the breakthrough moment."""

    outro = (
        f"And that's your complete guide to {topic}! "
        f"We covered the core framework, real examples, advanced strategies, and the mistakes to avoid. "
        f"If this helped you, hit that like button — it genuinely helps me reach more people. "
        f"Subscribe so you don't miss our next video. "
        f"And drop a comment: what's your single biggest takeaway from today? "
        f"I'll reply to as many as I can. See you in the next one!"
    )
    full = f"{hook}\n\n{intro}\n\n{body}\n\n{outro}"
    timestamps = [
        "0:00 - Introduction",
        f"2:30 - Core Framework",
        f"5:00 - Real-World Examples",
        f"7:30 - Advanced Strategies",
        f"9:00 - Common Mistakes",
        f"{duration-1}:00 - Conclusion"
    ]
    return {"hook": hook, "intro": intro, "body": body, "outro": outro,
            "timestamps": timestamps, "full_script": full}


# ─── SEO Generation ──────────────────────────────────────────────────────────

def generate_seo(topic: str, tone: str = "Educational", duration: int = 10) -> dict:
    """Generate SEO metadata via Ollama, with fallback."""
    system = "You are a YouTube SEO expert. Always respond with valid JSON only. No markdown, no explanation."
    prompt = f"""Generate complete YouTube SEO metadata.

Topic: {topic}
Tone: {tone}
Duration: {duration} minutes

Return ONLY this JSON:
{{
  "titles": [
    "Title 1 with power word + topic + benefit (under 60 chars)",
    "Title 2 with number + topic + promise",
    "Title 3 as a question",
    "Title 4 as how-to",
    "Title 5 with curiosity/shock angle"
  ],
  "description": "Complete 400+ word YouTube description with:\\n- Hook paragraph\\n- What you will learn (bullet list)\\n- Timestamps section\\n- About this channel\\n- Call to action\\n- Relevant hashtags at the bottom",
  "tags": ["tag1", "tag2", "...exactly 20 relevant tags mixing broad and specific"],
  "hashtags": ["#hashtag1", "#hashtag2", "...exactly 15 trending hashtags"],
  "category": "Education",
  "best_upload_time": "Tuesday or Thursday, 2-4 PM EST",
  "keyword_difficulty": "Medium",
  "trending_score": 74
}}"""

    try:
        raw = _ollama_chat(prompt, system, json_mode=True)
        data = json.loads(clean_json(raw))
        for key in ["titles", "description", "tags", "hashtags"]:
            if key not in data:
                raise ValueError(f"Missing SEO key: {key}")
        logger.info(f"SEO generated via Ollama for: {topic}")
        return data
    except Exception as e:
        logger.warning(f"SEO fallback triggered: {e}")
        return _fallback_seo(topic)


def _fallback_seo(topic: str) -> dict:
    kw = "".join(w.capitalize() for w in topic.split()[:2])
    words = topic.split()
    return {
        "titles": [
            f"The Complete Guide to {topic} (2024)",
            f"How to Master {topic} — Step by Step",
            f"Why {topic} Is Changing Everything Right Now",
            f"Top 10 {topic} Strategies That Actually Work",
            f"{topic} for Beginners: Everything You Need to Know",
        ],
        "description": (
            f"In this video, we break down everything you need to know about {topic}.\n\n"
            f"✅ WHAT YOU'LL LEARN:\n"
            f"• The fundamentals of {topic}\n"
            f"• Proven strategies used by top creators\n"
            f"• Common mistakes and how to avoid them\n"
            f"• Advanced tips to get ahead of 99% of people\n\n"
            f"🕐 TIMESTAMPS:\n"
            f"0:00 - Introduction\n"
            f"2:00 - Core Concepts\n"
            f"5:00 - Strategies\n"
            f"8:00 - Advanced Tips\n\n"
            f"🔔 Subscribe for weekly content on {topic} and more!\n"
            f"👍 Like if this helped you!\n"
            f"💬 Comment your biggest takeaway below!\n\n"
            f"#{kw} #YouTube #Tutorial #HowTo #2024"
        ),
        "tags": [
            topic, f"{topic} tutorial", f"learn {topic}", f"{topic} guide",
            f"{topic} tips", f"{topic} 2024", f"{topic} for beginners",
            f"{topic} explained", f"how to {topic}", f"best {topic}",
            "tutorial", "education", "how to", "beginners guide",
            "step by step", "tips and tricks", "complete guide",
            "youtube", "learning", "online education"
        ],
        "hashtags": [
            f"#{kw}", "#YouTube", "#Tutorial", "#Learning", "#Education",
            "#HowTo", "#Tips", "#Guide", "#2024", "#ContentCreator",
            "#Viral", "#Trending", "#Knowledge", "#Growth", "#Success"
        ],
        "category": "Education",
        "best_upload_time": "Tuesday or Thursday, 2-4 PM EST",
        "keyword_difficulty": "Medium",
        "trending_score": 68,
    }
