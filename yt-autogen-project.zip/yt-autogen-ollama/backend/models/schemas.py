"""Pydantic schemas for the generate endpoint."""
from pydantic import BaseModel, field_validator
from typing import Optional, List


class GenerateRequest(BaseModel):
    topic: str
    tone: str = "Educational"
    duration: int = 10
    thumbnail_style: str = "Cinematic"
    target_audience: Optional[str] = None
    language: str = "English"
    include_audio: bool = True

    @field_validator("duration")
    @classmethod
    def validate_duration(cls, v):
        if v not in [5, 10, 15, 20, 30]:
            raise ValueError("Duration must be 5, 10, 15, 20, or 30 minutes")
        return v

    @field_validator("thumbnail_style")
    @classmethod
    def validate_style(cls, v):
        valid = ["Cinematic", "Bold", "Minimalist", "Colorful", "Gaming"]
        if v not in valid:
            raise ValueError(f"Style must be one of: {', '.join(valid)}")
        return v


class ScriptSection(BaseModel):
    hook: str
    intro: str = ""
    body: str
    outro: str
    timestamps: List[str] = []
    full_script: str


class SEOSection(BaseModel):
    titles: List[str]
    description: str
    tags: List[str]
    hashtags: List[str]
    category: Optional[str] = "Education"
    best_upload_time: Optional[str] = ""
    keyword_difficulty: Optional[str] = ""
    trending_score: Optional[int] = 0


class GenerateResponse(BaseModel):
    success: bool
    project_id: int
    topic: str
    script: ScriptSection
    seo: SEOSection
    thumbnail: str   # base64 image
    audio: Optional[str] = None  # base64 mp3, may be None if disabled/failed
    word_count: int
    errors: dict = {}
