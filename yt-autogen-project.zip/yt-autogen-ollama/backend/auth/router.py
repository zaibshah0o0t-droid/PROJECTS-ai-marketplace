"""Authentication endpoints."""
import logging
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from backend.utils.database import get_db
from backend.auth.models import UserRegister, UserLogin, UserResponse, TokenResponse
from backend.auth.service import (
    create_user, authenticate_user, create_access_token,
    get_user_by_email, get_user_by_username,
)
from backend.auth.middleware import get_current_user
from backend.utils.database import User

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/auth", tags=["Authentication"])


@router.post("/register", response_model=TokenResponse, status_code=201)
async def register(data: UserRegister, db: Session = Depends(get_db)):
    if get_user_by_email(db, data.email):
        raise HTTPException(status_code=400, detail="Email already registered")
    if get_user_by_username(db, data.username):
        raise HTTPException(status_code=400, detail="Username already taken")
    user = create_user(db, data.username, data.email, data.password, data.full_name)
    token = create_access_token({"sub": str(user.id)})
    logger.info(f"New user registered: {user.username}")
    return TokenResponse(access_token=token, user=UserResponse.model_validate(user))


@router.post("/login", response_model=TokenResponse)
async def login(data: UserLogin, db: Session = Depends(get_db)):
    user = authenticate_user(db, data.email, data.password)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid email or password")
    token = create_access_token({"sub": str(user.id)})
    logger.info(f"User logged in: {user.username}")
    return TokenResponse(access_token=token, user=UserResponse.model_validate(user))


@router.get("/me", response_model=UserResponse)
async def get_me(current_user: User = Depends(get_current_user)):
    return UserResponse.model_validate(current_user)


@router.get("/stats")
async def get_stats(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    from backend.utils.database import Project, GenerationResult
    total_projects = db.query(Project).filter(Project.user_id == current_user.id).count()
    total_results = (
        db.query(GenerationResult)
        .join(Project)
        .filter(Project.user_id == current_user.id)
        .count()
    )
    return {"total_projects": total_projects, "total_generations": total_results}
