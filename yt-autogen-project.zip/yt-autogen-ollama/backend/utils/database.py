"""Database configuration and ORM models."""
import os
from datetime import datetime
from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime, Boolean, ForeignKey, event
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from dotenv import load_dotenv

load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./yt_autogen.db")
# timeout: how long (seconds) sqlite3 will wait for a lock before raising
# "database is locked", instead of failing instantly on any brief overlap.
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False, "timeout": 30})


@event.listens_for(engine, "connect")
def _set_sqlite_pragmas(dbapi_connection, connection_record):
    """WAL mode lets readers and writers work concurrently instead of
    blocking each other on every transaction — much friendlier for a
    multi-request local app than SQLite's default rollback-journal mode."""
    if DATABASE_URL.startswith("sqlite"):
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.execute("PRAGMA busy_timeout=30000")
        cursor.close()


SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


class User(Base):
    __tablename__ = "users"
    id            = Column(Integer, primary_key=True, index=True)
    username      = Column(String(100), unique=True, nullable=False, index=True)
    email         = Column(String(255), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    full_name     = Column(String(255), nullable=True)
    is_active     = Column(Boolean, default=True)
    created_at    = Column(DateTime, default=datetime.utcnow)
    projects      = relationship("Project", back_populates="user", cascade="all, delete-orphan")


class Project(Base):
    __tablename__ = "projects"
    id         = Column(Integer, primary_key=True, index=True)
    user_id    = Column(Integer, ForeignKey("users.id"), nullable=False)
    topic      = Column(String(500), nullable=False)
    tone       = Column(String(50), nullable=True)
    duration   = Column(Integer, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    user       = relationship("User", back_populates="projects")
    results    = relationship("GenerationResult", back_populates="project", cascade="all, delete-orphan")


class GenerationResult(Base):
    __tablename__ = "generation_results"
    id             = Column(Integer, primary_key=True, index=True)
    project_id     = Column(Integer, ForeignKey("projects.id"), nullable=False)
    script_hook    = Column(Text, nullable=True)
    script_body    = Column(Text, nullable=True)
    script_outro   = Column(Text, nullable=True)
    script_full    = Column(Text, nullable=True)
    seo_titles     = Column(Text, nullable=True)
    seo_description= Column(Text, nullable=True)
    seo_tags       = Column(Text, nullable=True)
    seo_hashtags   = Column(Text, nullable=True)
    thumbnail_b64  = Column(Text, nullable=True)
    audio_b64      = Column(Text, nullable=True)
    created_at     = Column(DateTime, default=datetime.utcnow)
    project        = relationship("Project", back_populates="results")


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db():
    Base.metadata.create_all(bind=engine)
