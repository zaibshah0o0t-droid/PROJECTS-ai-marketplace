"""YT AutoGen (Ollama Edition) — FastAPI Application Entry Point."""
import os
import sys
import logging
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from dotenv import load_dotenv

from backend.utils.database import init_db
from backend.auth.router import router as auth_router
from backend.routers.generate import router as generate_router

load_dotenv()
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger(__name__)

FRONTEND_URL = os.getenv("FRONTEND_URL", "http://127.0.0.1:5500")
THUMBNAIL_DIR = os.getenv("THUMBNAIL_DIR", "./backend/static/thumbnails")
UPLOAD_DIR = os.getenv("UPLOAD_DIR", "./backend/uploads")
AUDIO_DIR = os.getenv("AUDIO_DIR", "./backend/audio")
os.makedirs(THUMBNAIL_DIR, exist_ok=True)
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(AUDIO_DIR, exist_ok=True)

app = FastAPI(
    title="YT AutoGen — Ollama Edition",
    description="YouTube content generation powered by local Ollama models",
    version="2.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        FRONTEND_URL,
        "http://127.0.0.1:5500", "http://localhost:5500",
        "http://127.0.0.1:3000", "http://localhost:3000",
        "null",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/static", StaticFiles(directory="./backend/static"), name="static")

app.include_router(auth_router)
app.include_router(generate_router)


@app.on_event("startup")
async def startup():
    logger.info("Initialising database...")
    init_db()
    from fastapi.concurrency import run_in_threadpool
    from backend.services.ollama_service import _ollama_available, OLLAMA_MODEL
    if await run_in_threadpool(_ollama_available):
        logger.info(f"✅ Ollama reachable — using model '{OLLAMA_MODEL}'")
    else:
        logger.warning("⚠️  Ollama NOT reachable — fallback templates will be used for script/SEO")
    logger.info("YT AutoGen (Ollama Edition) started ✅")


@app.get("/")
async def root():
    return {"message": "YT AutoGen Ollama API is running", "version": "2.0.0", "docs": "/docs"}


@app.get("/health")
async def health():
    return {"status": "ok"}
