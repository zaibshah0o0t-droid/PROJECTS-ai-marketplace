"""
Main content generation endpoint.
POST /api/generate — generates script, SEO, thumbnail, and audio in one call.
"""
import json
import logging
from fastapi import APIRouter, Depends, HTTPException
from fastapi.concurrency import run_in_threadpool
from sqlalchemy.orm import Session

from backend.utils.database import get_db, Project, GenerationResult, User
from backend.auth.middleware import get_current_user
from backend.models.schemas import GenerateRequest, GenerateResponse, ScriptSection, SEOSection
from backend.services.ollama_service import generate_script, generate_seo
from backend.services.image_service import generate_thumbnail
from backend.services.voice_service import generate_voiceover_async

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api", tags=["Generate"])


@router.post("/generate", response_model=GenerateResponse)
async def generate_all(
    data: GenerateRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Generate complete YouTube content package:
    script (hook/body/outro/timestamps), SEO metadata, thumbnail, and voiceover audio.

    This endpoint NEVER hard-fails on a single component — each generator
    has its own fallback, and partial failures are reported in `errors`
    while still returning whatever succeeded.
    """
    topic = data.topic.strip()
    if not topic:
        raise HTTPException(status_code=400, detail="Topic cannot be empty")

    errors: dict = {}

    # NOTE: We deliberately do NOT touch the database here. Creating the
    # Project row up-front and only flushing (not committing) it used to
    # hold a SQLite write transaction open for the entire generation
    # pipeline (which can take 10-60s with a local LLM). If a second
    # request came in during that window, it hit "database is locked".
    # Instead we do all the slow work first, then write everything in a
    # single, fast, short-lived transaction at the very end.

    # ── 1. Script ─────────────────────────────────────────────────────────────
    script_data = {}
    try:
        script_data = await run_in_threadpool(
            generate_script,
            topic=topic, tone=data.tone, duration=data.duration,
            target_audience=data.target_audience, language=data.language,
        )
    except Exception as e:
        logger.error(f"Script generation error: {e}")
        errors["script"] = str(e)
        script_data = {"hook": "", "intro": "", "body": "", "outro": "",
                        "timestamps": [], "full_script": ""}

    # ── 2. SEO ────────────────────────────────────────────────────────────────
    seo_data = {}
    try:
        seo_data = await run_in_threadpool(
            generate_seo, topic=topic, tone=data.tone, duration=data.duration
        )
    except Exception as e:
        logger.error(f"SEO generation error: {e}")
        errors["seo"] = str(e)
        seo_data = {"titles": [], "description": "", "tags": [], "hashtags": []}

    # ── 3. Thumbnail ──────────────────────────────────────────────────────────
    thumbnail_b64 = ""
    try:
        thumbnail_b64 = await run_in_threadpool(
            generate_thumbnail, topic=topic, style_name=data.thumbnail_style
        )
    except Exception as e:
        logger.error(f"Thumbnail generation error: {e}")
        errors["thumbnail"] = str(e)

    # ── 4. Audio (optional) ───────────────────────────────────────────────────
    audio_b64 = None
    if data.include_audio:
        try:
            voiceover_text = script_data.get("full_script") or script_data.get("hook", "")
            if voiceover_text:
                audio_b64 = await generate_voiceover_async(voiceover_text, language=data.language)
        except Exception as e:
            logger.error(f"Audio generation error: {e}")
            errors["audio"] = str(e)

    # ── Persist result (single short transaction, after all slow work) ──────────
    project = Project(user_id=current_user.id, topic=topic, tone=data.tone, duration=data.duration)
    db.add(project)
    db.flush()
    pid = project.id

    result_row = GenerationResult(
        project_id=pid,
        script_hook=script_data.get("hook", ""),
        script_body=script_data.get("body", ""),
        script_outro=script_data.get("outro", ""),
        script_full=script_data.get("full_script", ""),
        seo_titles=json.dumps(seo_data.get("titles", [])),
        seo_description=seo_data.get("description", ""),
        seo_tags=json.dumps(seo_data.get("tags", [])),
        seo_hashtags=json.dumps(seo_data.get("hashtags", [])),
        thumbnail_b64=thumbnail_b64,
        audio_b64=audio_b64 or "",
    )
    db.add(result_row)
    db.commit()

    word_count = len((script_data.get("full_script") or "").split())

    return GenerateResponse(
        success=True,
        project_id=pid,
        topic=topic,
        script=ScriptSection(
            hook=script_data.get("hook", ""),
            intro=script_data.get("intro", ""),
            body=script_data.get("body", ""),
            outro=script_data.get("outro", ""),
            timestamps=script_data.get("timestamps", []),
            full_script=script_data.get("full_script", ""),
        ),
        seo=SEOSection(
            titles=seo_data.get("titles", []),
            description=seo_data.get("description", ""),
            tags=seo_data.get("tags", []),
            hashtags=seo_data.get("hashtags", []),
            category=seo_data.get("category", "Education"),
            best_upload_time=seo_data.get("best_upload_time", ""),
            keyword_difficulty=seo_data.get("keyword_difficulty", ""),
            trending_score=seo_data.get("trending_score", 0),
        ),
        thumbnail=thumbnail_b64,
        audio=audio_b64,
        word_count=word_count,
        errors=errors,
    )


@router.get("/health/ollama")
async def check_ollama_health():
    """Check if Ollama is reachable and which models are available."""
    from backend.services.ollama_service import _ollama_available, OLLAMA_HOST, OLLAMA_MODEL
    available = await run_in_threadpool(_ollama_available)
    return {
        "ollama_available": available,
        "host": OLLAMA_HOST,
        "configured_model": OLLAMA_MODEL,
        "message": "Ollama is reachable" if available else "Ollama not reachable — fallback templates will be used",
    }
