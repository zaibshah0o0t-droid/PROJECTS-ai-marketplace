'use strict';
const API = 'http://127.0.0.1:8000';

const state = {
  token: localStorage.getItem('yt_token') || '',
  user: JSON.parse(localStorage.getItem('yt_user') || 'null'),
  script: null, seo: null, thumbnail: null, audio: null,
  topic: '', style: 'Cinematic',
};

if (!state.token) window.location.href = 'login.html';

async function apiFetch(path, opts = {}) {
  const res = await fetch(`${API}${path}`, {
    ...opts,
    headers: { 'Authorization': `Bearer ${state.token}`, ...(opts.headers || {}) },
  });
  const data = await res.json().catch(() => ({ detail: 'Server error' }));
  if (res.status === 401) { logout(); return null; }
  if (!res.ok) throw new Error(data.detail || `Request failed (${res.status})`);
  return data;
}

function toast(msg, type = 'info', dur = 4000) {
  const icons = { success: '✅', error: '❌', info: 'ℹ️' };
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.innerHTML = `<span>${icons[type]}</span><span>${msg}</span>`;
  document.getElementById('toast-container').appendChild(el);
  setTimeout(() => el.remove(), dur);
}

function logout() {
  localStorage.removeItem('yt_token');
  localStorage.removeItem('yt_user');
  window.location.href = 'login.html';
}

function initUser() {
  if (!state.user) return;
  const initial = (state.user.full_name || state.user.username || 'U')[0].toUpperCase();
  document.getElementById('chip-avatar').textContent = initial;
  document.getElementById('chip-name').textContent = state.user.full_name || state.user.username;
}

async function checkOllama() {
  const badge = document.getElementById('ollama-badge');
  try {
    const data = await apiFetch('/api/health/ollama');
    if (data.ollama_available) {
      badge.textContent = `🟢 Ollama: ${data.configured_model}`;
      badge.className = 'badge-ollama online';
    } else {
      badge.textContent = '🟡 Ollama offline — using fallback templates';
      badge.className = 'badge-ollama offline';
    }
  } catch (_) {
    badge.textContent = 'Ollama status unknown';
  }
}

// ─── Result Tabs ──────────────────────────────────────────────────────────────
document.querySelectorAll('.rtab').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.rtab').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.rpanel').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById(`rpanel-${btn.dataset.rtab}`).classList.add('active');
  });
});
document.querySelectorAll('.stab').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.stab').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.script-pane').forEach(p => p.classList.add('hidden'));
    btn.classList.add('active');
    document.getElementById(`pane-${btn.dataset.stab}`).classList.remove('hidden');
  });
});

// ─── Generate ─────────────────────────────────────────────────────────────────
async function generateAll() {
  const topic = document.getElementById('topic').value.trim();
  if (!topic) { toast('Please enter a video topic', 'error'); return; }

  const btn = document.getElementById('generate-btn');
  const spinner = document.getElementById('gen-spinner');
  const genText = document.getElementById('gen-text');
  btn.disabled = true; spinner.classList.remove('hidden'); genText.textContent = 'Generating…';

  const includeAudio = document.getElementById('include-audio').checked;
  const progressArea = document.getElementById('progress-area');
  progressArea.classList.remove('hidden');
  setStep('ps-script', 'loading', '⏳ Working…');
  setStep('ps-seo', 'loading', '⏳ Working…');
  setStep('ps-thumb', 'loading', '⏳ Working…');
  setStep(includeAudio ? 'ps-audio' : 'ps-audio', includeAudio ? 'loading' : 'skip', includeAudio ? '⏳ Working…' : 'Skipped');

  const style = document.getElementById('thumb-style').value;
  state.topic = topic; state.style = style;

  const payload = {
    topic, tone: document.getElementById('tone').value,
    duration: parseInt(document.getElementById('duration').value),
    thumbnail_style: style,
    target_audience: document.getElementById('audience').value.trim() || null,
    language: document.getElementById('language').value,
    include_audio: includeAudio,
  };

  try {
    const data = await apiFetch('/api/generate', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!data) return;

    const errs = data.errors || {};

    state.script = data.script;
    setStep('ps-script', errs.script ? 'error' : 'done', errs.script ? '❌ Failed' : '✅ Done');
    renderScript(data.script, data.word_count, payload.duration);

    state.seo = data.seo;
    setStep('ps-seo', errs.seo ? 'error' : 'done', errs.seo ? '❌ Failed' : '✅ Done');
    renderSEO(data.seo);

    state.thumbnail = data.thumbnail;
    setStep('ps-thumb', errs.thumbnail ? 'error' : 'done', errs.thumbnail ? '❌ Failed' : '✅ Done');
    renderThumbnail(data.thumbnail);

    state.audio = data.audio;
    if (includeAudio) {
      setStep('ps-audio', errs.audio ? 'error' : (data.audio ? 'done' : 'error'),
        errs.audio ? '❌ Failed' : (data.audio ? '✅ Done' : '❌ No audio'));
    }
    renderAudio(data.audio);

    document.getElementById('results').classList.remove('hidden');

    if (Object.keys(errs).length) {
      toast(`Generated with some issues: ${Object.keys(errs).join(', ')}`, 'info');
    } else {
      toast('Content generated successfully!', 'success');
    }
  } catch (err) {
    toast(err.message, 'error');
    setStep('ps-script', 'error', '❌ Error');
    setStep('ps-seo', 'error', '❌ Error');
    setStep('ps-thumb', 'error', '❌ Error');
    setStep('ps-audio', 'error', '❌ Error');
  } finally {
    btn.disabled = false; spinner.classList.add('hidden'); genText.textContent = '⚡ Generate Everything';
  }
}

function setStep(id, cls, text) {
  const el = document.getElementById(id);
  if (!el) return;
  el.className = `progress-step ${cls}`;
  el.querySelector('.ps-status').textContent = text;
}

// ─── Render: Script ───────────────────────────────────────────────────────────
function renderScript(script, wordCount, duration) {
  document.getElementById('pane-hook').textContent = script.hook || '';
  document.getElementById('pane-intro').textContent = script.intro || '';
  document.getElementById('pane-body').textContent = script.body || '';
  document.getElementById('pane-outro').textContent = script.outro || '';
  document.getElementById('pane-timestamps').textContent = (script.timestamps || []).join('\n');
  document.getElementById('pane-full').textContent = script.full_script || '';

  const wc = wordCount || (script.full_script || '').split(' ').length;
  document.getElementById('script-meta').innerHTML = `
    <span>📊 ${wc.toLocaleString()} words</span>
    <span>🎯 ~${Math.round(wc / 150)} min video</span>`;
}

function copyFullScript() {
  if (!state.script) return toast('No script to copy', 'error');
  copyText(state.script.full_script || '', 'Full script copied!');
}
function downloadScript() {
  if (!state.script) return toast('No script to download', 'error');
  const s = state.script;
  const content = [
    `=== HOOK ===\n${s.hook}`, `\n=== INTRO ===\n${s.intro}`, `\n=== BODY ===\n${s.body}`,
    `\n=== OUTRO ===\n${s.outro}`, `\n=== TIMESTAMPS ===\n${(s.timestamps||[]).join('\n')}`,
    `\n\n=== FULL SCRIPT ===\n${s.full_script}`,
  ].join('\n');
  downloadText(content, `${slugify(state.topic)}-script.txt`);
  toast('Script downloaded!', 'success');
}

// ─── Render: Thumbnail ────────────────────────────────────────────────────────
function renderThumbnail(b64) {
  document.getElementById('thumb-img').src = `data:image/jpeg;base64,${b64}`;
}
function downloadThumbnail() {
  if (!state.thumbnail) return toast('No thumbnail to download', 'error');
  const a = document.createElement('a');
  a.href = `data:image/jpeg;base64,${state.thumbnail}`;
  a.download = 'thumbnail.jpg'; a.click();
  toast('Thumbnail downloaded!', 'success');
}
async function regenerateThumbnail() {
  if (!state.topic) return toast('Generate content first', 'error');
  try {
    toast('Regenerating thumbnail…', 'info');
    const data = await apiFetch('/api/generate', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        topic: state.topic, tone: document.getElementById('tone').value,
        duration: parseInt(document.getElementById('duration').value),
        thumbnail_style: state.style, language: document.getElementById('language').value,
        include_audio: false,
      }),
    });
    if (!data) return;
    state.thumbnail = data.thumbnail;
    renderThumbnail(data.thumbnail);
    toast('New thumbnail generated!', 'success');
  } catch (err) { toast(err.message, 'error'); }
}
function openModal() {
  if (!state.thumbnail) return;
  document.getElementById('modal-img').src = `data:image/jpeg;base64,${state.thumbnail}`;
  document.getElementById('modal').classList.remove('hidden');
}
function closeModal() { document.getElementById('modal').classList.add('hidden'); }

// ─── Render: SEO ──────────────────────────────────────────────────────────────
function renderSEO(seo) {
  document.getElementById('seo-titles').innerHTML = (seo.titles || []).map((t, i) =>
    `<div class="title-item" onclick="copyText('${t.replace(/'/g, "\\'")}','Title copied!')">${i+1}. ${t}</div>`
  ).join('');
  document.getElementById('seo-tags').innerHTML = (seo.tags || [])
    .map(t => `<span class="tag-chip" onclick="copyText('${t}','Tag copied!')">${t}</span>`).join('');
  document.getElementById('seo-hashtags').innerHTML = (seo.hashtags || [])
    .map(h => `<span class="hash-chip" onclick="copyText('${h}','Hashtag copied!')">${h}</span>`).join('');
  document.getElementById('seo-description').textContent = seo.description || '';
  document.getElementById('seo-stats').innerHTML = `
    <div class="stat-row"><span class="k">Category</span><span>${seo.category || '—'}</span></div>
    <div class="stat-row"><span class="k">Best Upload Time</span><span>${seo.best_upload_time || '—'}</span></div>
    <div class="stat-row"><span class="k">Keyword Difficulty</span><span>${seo.keyword_difficulty || '—'}</span></div>
    <div class="stat-row"><span class="k">Trending Score</span><span>${seo.trending_score || 0}/100</span></div>`;
}
function copyTitles() { if (state.seo?.titles) copyText(state.seo.titles.join('\n'), 'Titles copied!'); }
function copyTags() { if (state.seo?.tags) copyText(state.seo.tags.join(', '), 'Tags copied!'); }
function copyHashtags() { if (state.seo?.hashtags) copyText(state.seo.hashtags.join(' '), 'Hashtags copied!'); }
function copyDescription() { if (state.seo?.description) copyText(state.seo.description, 'Description copied!'); }
function copyAllSEO() {
  if (!state.seo) return toast('No SEO data', 'error');
  const s = state.seo;
  const text = [`TITLES:\n${(s.titles||[]).join('\n')}`, `\nTAGS:\n${(s.tags||[]).join(', ')}`,
    `\nHASHTAGS:\n${(s.hashtags||[]).join(' ')}`, `\nDESCRIPTION:\n${s.description||''}`].join('\n\n');
  copyText(text, 'All SEO data copied!');
}
function downloadSEO() {
  if (!state.seo) return toast('No SEO data', 'error');
  downloadText(JSON.stringify(state.seo, null, 2), `${slugify(state.topic)}-seo.json`);
  toast('SEO report downloaded!', 'success');
}

// ─── Render: Audio ────────────────────────────────────────────────────────────
function renderAudio(b64) {
  const empty = document.getElementById('audio-empty');
  const player = document.getElementById('audio-player');
  if (b64) {
    player.src = `data:audio/mp3;base64,${b64}`;
    player.classList.remove('hidden');
    empty.classList.add('hidden');
  } else {
    player.classList.add('hidden');
    empty.classList.remove('hidden');
  }
}
function downloadAudio() {
  if (!state.audio) return toast('No audio to download', 'error');
  const a = document.createElement('a');
  a.href = `data:audio/mp3;base64,${state.audio}`;
  a.download = `${slugify(state.topic)}-voiceover.mp3`; a.click();
  toast('Audio downloaded!', 'success');
}

// ─── Utilities ────────────────────────────────────────────────────────────────
function copyText(text, msg = 'Copied!') {
  navigator.clipboard.writeText(text).then(() => toast(msg, 'success')).catch(() => {
    const ta = document.createElement('textarea');
    ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select(); document.execCommand('copy'); document.body.removeChild(ta);
    toast(msg, 'success');
  });
}
function downloadText(content, filename) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([content], { type: 'text/plain' }));
  a.download = filename; a.click(); URL.revokeObjectURL(a.href);
}
function slugify(text) {
  return (text || 'project').toLowerCase().replace(/[^\w\s-]/g, '').replace(/[\s_-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40);
}

initUser();
checkOllama();
